<?php

namespace Drupal\bemanti;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of Bemanti user group entity entities.
 *
 * @ingroup bemanti
 */
class BemantiUserGroupEntityListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('Bemanti user group entity ID');
    $header['name'] = $this->t('Name');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var \Drupal\bemanti\Entity\BemantiUserGroupEntity $entity */
    $row['id'] = $entity->id();
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.bemanti_user_group.edit_form',
      ['bemanti_user_group' => $entity->id()]
    );
    return $row + parent::buildRow($entity);
  }

}
