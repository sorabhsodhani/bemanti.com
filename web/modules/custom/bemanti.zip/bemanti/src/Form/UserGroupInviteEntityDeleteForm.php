<?php

namespace Drupal\bemanti\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting User group invite entity entities.
 *
 * @ingroup bemanti
 */
class UserGroupInviteEntityDeleteForm extends ContentEntityDeleteForm {


}
