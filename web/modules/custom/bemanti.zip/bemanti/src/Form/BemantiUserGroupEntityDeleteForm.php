<?php

namespace Drupal\bemanti\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Bemanti user group entity entities.
 *
 * @ingroup bemanti
 */
class BemantiUserGroupEntityDeleteForm extends ContentEntityDeleteForm {


}
