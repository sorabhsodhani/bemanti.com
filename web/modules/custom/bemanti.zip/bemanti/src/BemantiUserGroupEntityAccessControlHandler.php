<?php

namespace Drupal\bemanti;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the Bemanti user group entity entity.
 *
 * @see \Drupal\bemanti\Entity\BemantiUserGroupEntity.
 */
class BemantiUserGroupEntityAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\bemanti\Entity\BemantiUserGroupEntityInterface $entity */

    switch ($operation) {

      case 'view':

        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished bemanti user group entity entities');
        }


        return AccessResult::allowedIfHasPermission($account, 'view published bemanti user group entity entities');

      case 'update':

        return AccessResult::allowedIfHasPermission($account, 'edit bemanti user group entity entities');

      case 'delete':

        return AccessResult::allowedIfHasPermission($account, 'delete bemanti user group entity entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add bemanti user group entity entities');
  }


}
