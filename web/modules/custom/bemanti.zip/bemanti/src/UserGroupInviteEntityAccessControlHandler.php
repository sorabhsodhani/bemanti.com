<?php

namespace Drupal\bemanti;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the User group invite entity entity.
 *
 * @see \Drupal\bemanti\Entity\UserGroupInviteEntity.
 */
class UserGroupInviteEntityAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\bemanti\Entity\UserGroupInviteEntityInterface $entity */

    switch ($operation) {

      case 'view':

        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished user group invite entity entities');
        }


        return AccessResult::allowedIfHasPermission($account, 'view published user group invite entity entities');

      case 'update':

        return AccessResult::allowedIfHasPermission($account, 'edit user group invite entity entities');

      case 'delete':

        return AccessResult::allowedIfHasPermission($account, 'delete user group invite entity entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add user group invite entity entities');
  }


}
