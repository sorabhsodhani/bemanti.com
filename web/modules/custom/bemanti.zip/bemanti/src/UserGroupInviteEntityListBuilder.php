<?php

namespace Drupal\bemanti;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of User group invite entity entities.
 *
 * @ingroup bemanti
 */
class UserGroupInviteEntityListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('User group invite entity ID');
    $header['name'] = $this->t('Name');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var \Drupal\bemanti\Entity\UserGroupInviteEntity $entity */
    $row['id'] = $entity->id();
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.user_group_invite_entity.edit_form',
      ['user_group_invite_entity' => $entity->id()]
    );
    return $row + parent::buildRow($entity);
  }

}
