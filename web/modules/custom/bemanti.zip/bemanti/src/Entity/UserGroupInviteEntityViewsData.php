<?php

namespace Drupal\bemanti\Entity;

use Drupal\views\EntityViewsData;

/**
 * Provides Views data for User group invite entity entities.
 */
class UserGroupInviteEntityViewsData extends EntityViewsData {

  /**
   * {@inheritdoc}
   */
  public function getViewsData() {
    $data = parent::getViewsData();

    // Additional information for Views integration, such as table joins, can be
    // put here.
    return $data;
  }

}
