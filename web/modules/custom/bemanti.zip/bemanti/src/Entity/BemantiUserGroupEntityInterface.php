<?php

namespace Drupal\bemanti\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Bemanti user group entity entities.
 *
 * @ingroup bemanti
 */
interface BemantiUserGroupEntityInterface extends ContentEntityInterface, EntityChangedInterface, EntityPublishedInterface, EntityOwnerInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */

  /**
   * Gets the Bemanti user group entity name.
   *
   * @return string
   *   Name of the Bemanti user group entity.
   */
  public function getName();

  /**
   * Sets the Bemanti user group entity name.
   *
   * @param string $name
   *   The Bemanti user group entity name.
   *
   * @return \Drupal\bemanti\Entity\BemantiUserGroupEntityInterface
   *   The called Bemanti user group entity entity.
   */
  public function setName($name);

  /**
   * Gets the Bemanti user group entity creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Bemanti user group entity.
   */
  public function getCreatedTime();

  /**
   * Sets the Bemanti user group entity creation timestamp.
   *
   * @param int $timestamp
   *   The Bemanti user group entity creation timestamp.
   *
   * @return \Drupal\bemanti\Entity\BemantiUserGroupEntityInterface
   *   The called Bemanti user group entity entity.
   */
  public function setCreatedTime($timestamp);

}
